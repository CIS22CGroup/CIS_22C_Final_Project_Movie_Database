var searchData=
[
  ['negation',['negation',['../structnlohmann_1_1detail_1_1negation.html',1,'nlohmann::detail']]]
];
