var searchData=
[
  ['type_5ferror',['type_error',['../classnlohmann_1_1basic__json.html#a4010e8e268fefd86da773c10318f2902',1,'nlohmann::basic_json']]]
];
