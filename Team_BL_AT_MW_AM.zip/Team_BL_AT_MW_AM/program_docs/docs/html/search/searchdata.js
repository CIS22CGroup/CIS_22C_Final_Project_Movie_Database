var indexSectionsWithContent =
{
  0: "abcdefghijklmnoprstuvw~",
  1: "abcefhijlmnopstw",
  2: "n",
  3: "abcdefghijklmnoprstuvw~",
  4: "abiop",
  5: "abcdeijnoprstv",
  6: "ptv",
  7: "abdeklnopsuv",
  8: "bo",
  9: "dm"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Pages"
};

