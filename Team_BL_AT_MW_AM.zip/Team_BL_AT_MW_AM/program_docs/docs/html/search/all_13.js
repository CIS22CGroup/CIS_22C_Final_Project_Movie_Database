var searchData=
[
  ['unflatten',['unflatten',['../classnlohmann_1_1basic__json.html#a74fa3ab2003f2f6f2b69deaafed9126d',1,'nlohmann::basic_json']]],
  ['unget_5fcharacter',['unget_character',['../structnlohmann_1_1detail_1_1input__adapter__protocol.html#aeb5cac3e86e8df6cfe48cc42de2e9225',1,'nlohmann::detail::input_adapter_protocol::unget_character()'],['../classnlohmann_1_1detail_1_1input__stream__adapter.html#ab6a65d3816ce4027ef4d2013a13ee697',1,'nlohmann::detail::input_stream_adapter::unget_character()'],['../classnlohmann_1_1detail_1_1input__buffer__adapter.html#ae2464d8e963d2ae617b080f2df2550a1',1,'nlohmann::detail::input_buffer_adapter::unget_character()']]],
  ['uninitialized',['uninitialized',['../classnlohmann_1_1detail_1_1lexer.html#a3f313cdbe187cababfc5e06f0b69b098a42dd1a73d072bb6bf3f494f22b15db8e',1,'nlohmann::detail::lexer']]],
  ['update',['update',['../classnlohmann_1_1basic__json.html#a1cfa9ae5e7c2434cab4cfe69bffffe11',1,'nlohmann::basic_json::update(const_reference j)'],['../classnlohmann_1_1basic__json.html#a27921dafadb3bbefd180235ec763e3ea',1,'nlohmann::basic_json::update(const_iterator first, const_iterator last)']]]
];
