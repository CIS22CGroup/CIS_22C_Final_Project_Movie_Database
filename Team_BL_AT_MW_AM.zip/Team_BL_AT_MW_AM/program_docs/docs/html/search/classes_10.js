var searchData=
[
  ['winhttp',['WinHTTP',['../class_win_h_t_t_p.html',1,'']]]
];
