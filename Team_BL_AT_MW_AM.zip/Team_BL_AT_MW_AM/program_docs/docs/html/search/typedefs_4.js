var searchData=
[
  ['exception',['exception',['../classnlohmann_1_1basic__json.html#a9a0aced019cb1d65bb49703406c84970',1,'nlohmann::basic_json']]]
];
