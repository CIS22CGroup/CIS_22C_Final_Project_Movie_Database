var searchData=
[
  ['input_5fadapter_5ft',['input_adapter_t',['../namespacenlohmann_1_1detail.html#ae132f8cd5bb24c5e9b40ad0eafedf1c2',1,'nlohmann::detail']]],
  ['invalid_5fiterator',['invalid_iterator',['../classnlohmann_1_1basic__json.html#ac13d32f7cbd02d616e71d8dc30dadcbf',1,'nlohmann::basic_json']]],
  ['iterator',['iterator',['../classnlohmann_1_1basic__json.html#a099316232c76c034030a38faa6e34dca',1,'nlohmann::basic_json']]]
];
