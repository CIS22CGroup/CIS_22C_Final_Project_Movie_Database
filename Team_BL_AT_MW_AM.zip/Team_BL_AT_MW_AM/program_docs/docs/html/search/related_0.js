var searchData=
[
  ['basic_5fjson',['basic_json',['../classnlohmann_1_1json__pointer.html#ada3100cdb8700566051828f1355fa745',1,'nlohmann::json_pointer']]]
];
